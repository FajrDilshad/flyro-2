# Test package initializer.
